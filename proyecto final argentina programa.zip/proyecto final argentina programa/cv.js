function enAmarillo1() {
  Element =document.getElementById("pers");
  Element.src="imagenes/personal2.png";
  }
  function enNegro1() {
      Element =document.getElementById("pers");
      Element.src="imagenes/personal.png";
  }
  
  function enAmarillo2() {
      Element =document.getElementById("labo");
      Element.src="imagenes/laboral2.png";
  }
   function enNegro2() {
      Element =document.getElementById("labo");
      Element.src="imagenes/laboral.png";
  }
  
  function enAmarillo3() {
      Element =document.getElementById("habi");
      Element.src="imagenes/habilidades2.png";
  }
  function enNegro3() {
      Element =document.getElementById("habi");
      Element.src="imagenes/habilidades.png";
  }
  
  function enAmarillo4() {
      Element =document.getElementById("estu");
      Element.src="imagenes/estudios2.png";
  }
  function enNegro4() {
      Element =document.getElementById("estu");
      Element.src="imagenes/estudios.png";
  }
  
  function enAmarillo5() {
      Element =document.getElementById("be");
      Element.src="imagenes/behance2.png";
  }
  function enNegro5() {
      Element =document.getElementById("be");
      Element.src="imagenes/behance.png";
  }
  
  function enAmarillo6() {
      Element =document.getElementById("gi");
      Element.src="imagenes/github2.png";
  }
  function enNegro6() {
      Element =document.getElementById("gi");
      Element.src="imagenes/github.png";
  }
  
  function enAmarillo7() {
      Element =document.getElementById("li");
      Element.src="imagenes/linkedin2.png";
  }
  function enNegro7() {
      Element =document.getElementById("li");
      Element.src="imagenes/linkedin.png";
  }
  